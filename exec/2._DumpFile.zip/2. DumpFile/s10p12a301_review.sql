-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s10p12a301
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `created_at` datetime(6) NOT NULL,
  `event_id` bigint(20) DEFAULT NULL,
  `review_id` bigint(20) NOT NULL,
  `update_at` datetime(6) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `content` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES ('2024-02-08 01:41:11.080439',1,1,'2024-02-08 01:41:11.080439',622,'ㅇㅇㄷㄷ','https://togeduck.s3.ap-northeast-2.amazonaws.com/424e5f11-ad47-4f07-89fd-4c7e49bf2d4cScreenshot_20240114-233122_ImageTrackHelp.jpg'),('2024-02-08 01:46:43.590061',1,2,'2024-02-08 01:46:43.590061',653,'ㄹㄹ','https://togeduck.s3.ap-northeast-2.amazonaws.com/aa2f7295-9190-4cb2-bced-f6c5f81637d51000000034.jpg'),('2024-02-08 03:17:32.887367',784,3,'2024-02-08 03:17:32.887367',662,'ㅇㄴㅇㅇ','https://togeduck.s3.ap-northeast-2.amazonaws.com/fb867647-e89c-439b-b7ec-be0bf84873f21000000034.jpg'),('2024-02-08 03:19:02.514205',784,4,'2024-02-08 03:19:02.514205',665,'ㄹㄹ','https://togeduck.s3.ap-northeast-2.amazonaws.com/28da9eec-3488-485b-992a-03271b4c83281000000034.jpg'),('2024-02-08 03:22:02.635585',784,5,'2024-02-08 03:22:02.635585',669,'ㄹㄹㄹㄹ','https://togeduck.s3.ap-northeast-2.amazonaws.com/78837bc0-8bc0-4a12-8130-a4a90f29dd031000000034.jpg'),('2024-02-08 03:23:10.195614',784,6,'2024-02-08 03:23:10.195614',670,'ㅎㅎㅎㅎ','https://togeduck.s3.ap-northeast-2.amazonaws.com/4c55663a-7602-4284-ba7f-464bd43fcc081000000033.jpg'),('2024-02-08 03:41:07.552866',784,7,'2024-02-08 03:41:07.552866',682,'ㅎㅎㅎㅎㅎㅎ','https://togeduck.s3.ap-northeast-2.amazonaws.com/35cee470-afd3-4ca2-8f8a-157e75c7051b1000000033.jpg'),('2024-02-09 12:08:52.273625',554,52,'2024-02-09 12:08:52.273625',1013,'ㅅㅈㅅㄷㄴㅈㅅ','https://togeduck.s3.ap-northeast-2.amazonaws.com/010ad317-2fe5-4663-9ab6-46d836bbddf2Screenshot_20240205_122716_TogeDuck.jpg'),('2024-02-09 13:56:05.824915',552,53,'2024-02-09 13:56:05.824915',1048,'ㅎ','https://togeduck.s3.ap-northeast-2.amazonaws.com/90753523-349e-48f4-b75c-ce138c6eb12eScreenshot_20240205_122716_TogeDuck.jpg'),('2024-02-11 05:47:16.115328',552,54,'2024-02-11 05:47:16.115328',1273,'ㅎ','https://togeduck.s3.ap-northeast-2.amazonaws.com/bd93da0c-9353-45e8-bd6d-bb0c79cb485cScreenshot_20240205_122716_TogeDuck.jpg'),('2024-02-11 06:05:03.787030',552,55,'2024-02-11 06:05:03.787030',1287,'ㅎ','https://togeduck.s3.ap-northeast-2.amazonaws.com/f10a281b-db3a-434c-953a-257499ed5099Screenshot_20240205_122716_TogeDuck.jpg'),('2024-02-11 06:19:48.762705',552,56,'2024-02-11 06:19:48.762705',1291,'ㅅ','https://togeduck.s3.ap-northeast-2.amazonaws.com/34bae753-6c9d-4f2a-87bf-4293d2dee21cScreenshot_20240205_122716_TogeDuck.jpg'),('2024-02-11 06:22:15.487974',552,57,'2024-02-11 06:22:15.487974',1293,'ㅅ','https://togeduck.s3.ap-northeast-2.amazonaws.com/ea3a7e07-05c8-4fcf-b895-3570579f094fScreenshot_20240205_122716_TogeDuck.jpg'),('2024-02-11 06:25:47.245571',552,58,'2024-02-11 06:25:47.245571',1294,'ㅅ','https://togeduck.s3.ap-northeast-2.amazonaws.com/d40e49eb-c51f-4697-a95c-25f649f5b7abScreenshot_20240205_122716_TogeDuck.jpg'),('2024-02-11 06:26:39.990857',552,59,'2024-02-11 06:26:39.990857',1295,'ㅂ','https://togeduck.s3.ap-northeast-2.amazonaws.com/5bc9f7da-d601-4b94-83f9-62004596207dScreenshot_20240205_122716_TogeDuck.jpg'),('2024-02-11 10:52:07.840664',552,60,'2024-02-11 10:52:07.840664',1407,'ㅅ','https://togeduck.s3.ap-northeast-2.amazonaws.com/45a50cf2-b051-4a80-a859-d6398935cf75Screenshot_20240205_122716_TogeDuck.jpg'),('2024-02-11 11:50:43.727731',67,61,'2024-02-11 11:50:43.727731',1417,'ㄴ','https://togeduck.s3.ap-northeast-2.amazonaws.com/f2a4b1e1-7677-4d96-aa66-f26d12dfe031Screenshot_20240205_163453_TogeDuck.jpg'),('2024-02-13 01:24:29.735404',1017,102,'2024-02-13 01:24:29.735404',1904,'ㅎ',NULL),('2024-02-13 01:38:34.413060',1017,152,'2024-02-13 01:38:34.413060',1961,'ㅂㅂ',NULL),('2024-02-13 01:40:08.070704',1017,153,'2024-02-13 01:40:08.070704',1961,'ㅅ',NULL),('2024-02-13 01:52:11.832658',1017,154,'2024-02-13 01:52:11.832658',1961,'ㄹㄹ','https://togeduck.s3.ap-northeast-2.amazonaws.com/3c78cbb6-0468-4e05-8dd7-2873111b995fScreenshot_20240211_202352_TogeDuck.jpg'),('2024-02-13 03:12:53.027402',1017,202,'2024-02-13 03:12:53.027402',2039,'라',NULL),('2024-02-13 03:20:15.043662',1017,203,'2024-02-13 03:20:15.043662',2043,'리뷰입니다다다다다','https://togeduck.s3.ap-northeast-2.amazonaws.com/1278818e-5abe-42d2-9373-56f323ce11e1Screenshot_20240213_121953_Google.jpg'),('2024-02-13 03:27:44.800713',1017,252,'2024-02-13 03:27:44.800713',2102,'리뷰2222','https://togeduck.s3.ap-northeast-2.amazonaws.com/c6972378-0b67-4dad-83e1-1a95cdc82c71Screenshot_20240213_121953_Google.jpg'),('2024-02-13 06:44:12.829741',67,302,'2024-02-13 06:44:12.829741',2213,'좋아요',NULL),('2024-02-13 06:44:19.004535',67,303,'2024-02-13 06:44:19.004535',2213,'ㅠㅠㅠ',NULL),('2024-02-13 07:26:22.408803',1017,352,'2024-02-13 07:26:22.408803',2252,'???',NULL),('2024-02-14 00:28:42.496080',1064,402,'2024-02-14 00:28:42.496080',2353,'ㅎㅎ',NULL),('2024-02-14 00:29:16.908031',1064,403,'2024-02-14 00:29:16.908031',2353,'좋아요',NULL),('2024-02-14 01:31:10.447724',1017,404,'2024-02-14 01:31:10.447724',2405,'ㅎㅎ',NULL),('2024-02-15 01:32:59.968322',1014,452,'2024-02-15 01:32:59.968322',909,'너무 좋았어요!',NULL),('2024-02-15 01:45:01.460400',67,453,'2024-02-15 01:45:01.460400',2516,'리뷰!',NULL),('2024-02-15 05:23:15.973542',1098,502,'2024-02-15 05:23:15.973542',2558,'우리홉! 생일 축하해!!! 보라해♡',NULL),('2024-02-15 05:23:39.248655',1098,503,'2024-02-15 05:23:39.248655',2558,'홉아 얼른 복무 마치구 전역하구 보자! 홧팅 ㅎ',NULL),('2024-02-15 05:24:24.577200',1098,504,'2024-02-15 05:24:24.577200',2558,'아미가 기다리고 있어! 생일 츄카포카!','https://togeduck.s3.ap-northeast-2.amazonaws.com/e3e7fd83-6372-45a9-abea-91978994cbec1000011388.jpg'),('2024-02-15 05:24:57.732812',1098,505,'2024-02-15 05:24:57.732812',2559,'?',NULL),('2024-02-15 05:25:35.554756',1098,506,'2024-02-15 05:25:35.554756',909,'정조교님 군번줄!! 꼭 얻고싶어서 찾아갔는데 이런 행운이..!!!ㅠㅠㅠ 너무너무 행복한 하루네요! 다들 방문하시고 우리 정조교님 생일 많이 축하해주세요 ❤️','https://togeduck.s3.ap-northeast-2.amazonaws.com/01dd5d3f-ccb6-4d95-81ca-580711cd04991000001551.jpg'),('2024-02-15 05:25:57.274991',1098,507,'2024-02-15 05:25:57.274991',2558,'24년은 홉이 전역의 해 ? 생일 축하해 ??',NULL),('2024-02-15 05:27:09.187329',1098,508,'2024-02-15 05:27:09.187329',2558,'생일 축하해!!! 아미랑 영원하쟈?','https://togeduck.s3.ap-northeast-2.amazonaws.com/887f9603-405f-4871-bed9-ff025793374a1000011389.jpg'),('2024-02-15 05:32:39.216850',1098,509,'2024-02-15 05:32:39.216850',2559,'다들 홉이 축하하러 여기가시면 밀크티 꼭 사먹어보세요!',NULL),('2024-02-15 08:32:27.904098',1098,510,'2024-02-15 08:32:27.904098',2559,'완전 대박!',NULL),('2024-02-15 08:33:15.640160',1098,511,'2024-02-15 08:33:15.640160',2559,'대박',NULL),('2024-02-15 08:36:22.454134',1098,512,'2024-02-15 08:36:22.454134',2559,'가고싶다...',NULL),('2024-02-15 08:39:03.358795',1098,513,'2024-02-15 08:39:03.358795',2559,'내일 가야지',NULL),('2024-02-15 13:01:12.062686',1098,514,'2024-02-15 13:01:12.062686',2559,'홉이 생일 축하해!',NULL),('2024-02-15 13:03:27.000056',1098,515,'2024-02-15 13:03:27.000056',2559,'보라해!',NULL);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  1:19:21
