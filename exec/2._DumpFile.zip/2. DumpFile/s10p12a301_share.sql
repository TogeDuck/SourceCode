-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s10p12a301
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `share`
--

DROP TABLE IF EXISTS `share`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `share` (
  `duration` int(11) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `event_id` bigint(20) DEFAULT NULL,
  `share_id` bigint(20) NOT NULL,
  `update_at` datetime(6) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `content` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`share_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `share`
--

LOCK TABLES `share` WRITE;
/*!40000 ALTER TABLE `share` DISABLE KEYS */;
INSERT INTO `share` VALUES (120,'2024-02-12 13:00:28.338232',561,202,'2024-02-12 13:00:28.338232',1568,'ㅇㅇ','https://togeduck.s3.ap-northeast-2.amazonaws.com/e501f245-e441-4f2b-8b9e-d43016926234Screenshot_20240114-233122_ImageTrackHelp.jpg','되나?'),(120,'2024-02-12 13:01:15.408054',561,203,'2024-02-12 13:01:15.408054',1568,'살려','https://togeduck.s3.ap-northeast-2.amazonaws.com/49eb37d0-d23b-49c1-acc5-2640bde3539dimage-ngzywpwu6jb1jdpk9pa7nw7zre.png','으으'),(120,'2024-02-12 13:01:44.134472',561,204,'2024-02-12 13:01:44.134472',1568,'merge','https://togeduck.s3.ap-northeast-2.amazonaws.com/49363a84-41b3-4b8f-8d32-e090b255c014image-ngzywpwu6jb1jdpk9pa7nw7zre.png','뭐지'),(120,'2024-02-12 13:03:06.808032',564,205,'2024-02-12 13:03:06.808032',1602,'djdj','https://togeduck.s3.ap-northeast-2.amazonaws.com/b44ed9a5-28b8-4d89-93bb-7c366e41f9feScreenshot_20240114-233122_ImageTrackHelp.jpg','marr'),(120,'2024-02-12 13:03:22.669767',564,206,'2024-02-12 13:03:22.669767',1602,'shsu','https://togeduck.s3.ap-northeast-2.amazonaws.com/a9e0db8c-9133-4488-a1df-73628cf8dc63Screenshot_20240114-233122_ImageTrackHelp.jpg','sjsjjs'),(120,'2024-02-12 13:04:07.444505',68,207,'2024-02-12 13:04:07.444505',1603,'ㄱ','https://togeduck.s3.ap-northeast-2.amazonaws.com/88da1b9c-06c6-4ba9-bead-3a6e4b4fde05Screenshot_20240205_163453_TogeDuck.jpg','ㄱ'),(120,'2024-02-12 13:04:39.351266',68,208,'2024-02-12 13:04:39.351266',1603,'ㄴ','https://togeduck.s3.ap-northeast-2.amazonaws.com/527e2897-5091-4bc5-b490-5270bd2c7f10Screenshot_20240205_122716_TogeDuck.jpg','ㄴ'),(120,'2024-02-12 17:14:57.174641',570,209,'2024-02-12 17:14:57.174641',1646,'ㄷ','https://togeduck.s3.ap-northeast-2.amazonaws.com/d28d5264-6790-4575-b278-508dd2ab5126Screenshot_20240211_202352_TogeDuck.jpg','ㅌ'),(120,'2024-02-13 01:27:34.252194',72,252,'2024-02-13 01:27:34.252194',1903,'토터','https://togeduck.s3.ap-northeast-2.amazonaws.com/0ac3d30f-c79c-4702-b722-7991e8960703Screenshot_20240115-162711_Samsung%20Members.jpg','ㅠ쿠'),(120,'2024-02-13 07:57:28.908761',1065,302,'2024-02-13 07:57:28.908761',2302,'재환이 나눠요','https://togeduck.s3.ap-northeast-2.amazonaws.com/e08f6e9b-b304-4ef4-a20a-a1cdcd5b3f4b1000001449.jpg','차재환 나눔'),(120,'2024-02-14 00:14:48.245699',1017,352,'2024-02-14 00:14:48.245699',2360,'ㅁㅁ','https://togeduck.s3.ap-northeast-2.amazonaws.com/8c195051-3e3b-4d8a-b5f9-b38bb31548e3Screenshot_20240114-233122_ImageTrackHelp.jpg','ㅁㅁ'),(120,'2024-02-14 01:08:49.063000',1027,353,'2024-02-14 01:08:49.063000',2253,'나눔합니다','https://togeduck.s3.ap-northeast-2.amazonaws.com/f32a3433-c5f4-4095-b5c3-109b2682bb88Screenshot_20240213_121953_Google.jpg','나눔1'),(120,'2024-02-14 01:13:34.054546',1036,354,'2024-02-14 01:13:34.054546',2253,'나눔\n','https://togeduck.s3.ap-northeast-2.amazonaws.com/a7753ccb-4029-4f15-a26e-04905b351ea3Screenshot_20240213_121953_Google.jpg','나눔'),(120,'2024-02-14 01:14:06.945523',1018,355,'2024-02-14 01:14:06.945523',2253,'나눔','https://togeduck.s3.ap-northeast-2.amazonaws.com/5b46620a-f662-456d-933b-12d28266083dScreenshot_20240213_121953_Google.jpg','나눔ㄴ'),(120,'2024-02-14 01:22:33.535175',1028,356,'2024-02-14 01:22:33.535175',2253,'ㄴ','https://togeduck.s3.ap-northeast-2.amazonaws.com/0d750ece-37da-48a1-8c0f-c27894dcd624Screenshot_20240213_121953_Google.jpg','ㄹ'),(120,'2024-02-14 01:26:35.896443',1031,357,'2024-02-14 01:26:35.896443',2253,'ㄴ','https://togeduck.s3.ap-northeast-2.amazonaws.com/35a1ac77-a7cd-44ad-8e48-d674fc8600e1Screenshot_20240213_121953_Google.jpg','ㄴ'),(120,'2024-02-14 01:29:58.260836',1022,358,'2024-02-14 01:29:58.260836',2253,'포카 나눔해요','https://togeduck.s3.ap-northeast-2.amazonaws.com/e39b80e2-4230-42d7-b404-e95ae0a228dfScreenshot_20240213_121953_Google.jpg','포카 나눔해요'),(120,'2024-02-14 01:30:14.435734',1018,359,'2024-02-14 01:30:14.435734',2405,'.','https://togeduck.s3.ap-northeast-2.amazonaws.com/761e4131-5379-4d40-ba13-03680767429b1000011358.jpg','투게덕'),(120,'2024-02-14 07:46:04.759577',1017,402,'2024-02-14 07:46:04.759577',2453,'ㅌㅌ','https://togeduck.s3.ap-northeast-2.amazonaws.com/11b6df99-e301-491b-ae47-c324f6d77e35Screenshot_20240214-105245_TogeDuck.jpg','테슽'),(120,'2024-02-15 00:04:23.048535',1017,452,'2024-02-15 00:04:23.048535',2463,'나눔행','https://togeduck.s3.ap-northeast-2.amazonaws.com/1ea8d761-6260-4204-b6d6-dfa6979b645aScreenshot_20240213_121953_Google.jpg','나눔합니다'),(120,'2024-02-15 02:50:09.814992',1065,453,'2024-02-15 02:50:09.814992',2509,'나눔합니다','https://togeduck.s3.ap-northeast-2.amazonaws.com/cf4cf071-a0eb-4e3e-9964-d71f8f4155251000003446.jpg','ㅎㅎ'),(120,'2024-02-15 02:52:59.558698',1065,454,'2024-02-15 02:52:59.558698',2509,'제곧내','https://togeduck.s3.ap-northeast-2.amazonaws.com/fa597978-da1e-42f8-a6c2-87bbbdba22731000003430.jpg','싸피 노트북 나눔합니다'),(120,'2024-02-15 05:04:56.714756',1066,502,'2024-02-15 05:04:56.714756',2556,'나눔','https://togeduck.s3.ap-northeast-2.amazonaws.com/47073fa4-e468-418b-b37f-98481528d03720240214_175853.jpg','나ㅡ눔'),(120,'2024-02-15 05:30:18.557485',1098,503,'2024-02-15 05:30:18.557485',2558,'카페 책장 옆에 두고 갈께요! 필요하신분 가져가세요','https://togeduck.s3.ap-northeast-2.amazonaws.com/6a743312-25cd-486b-94e3-2d3821c7e01c1000011395.jpg','선착순 나눔!'),(120,'2024-02-15 05:31:39.206933',1098,504,'2024-02-15 05:31:39.206933',2558,'홉이 포카 네장 나눔합니다.','https://togeduck.s3.ap-northeast-2.amazonaws.com/1cd41f05-7874-484f-a772-349b9bb6850c1000011396.jpg','4장 나눔합니다!'),(120,'2024-02-15 05:32:35.865165',1098,505,'2024-02-15 05:32:35.865165',2558,'약간 하자있지만 나눔 합니다!!\n테이블 위에 올려놨어요!','https://togeduck.s3.ap-northeast-2.amazonaws.com/9cad0e4e-3b50-4cd4-a354-dbbebcf0d4cd1000011397.jpg','교복홉'),(120,'2024-02-15 13:37:34.348105',1098,506,'2024-02-15 13:37:34.348105',2559,'가져가세요','https://togeduck.s3.ap-northeast-2.amazonaws.com/4989edae-f1c1-449c-bd09-686e3a7164fb1000002287.jpg','나눔');
/*!40000 ALTER TABLE `share` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  1:19:29
